package com.example.weather;

import com.google.gson.annotations.SerializedName;

public class MyWeather {
    @SerializedName("description")
    private String description;

    public String getDescription() {
        return description;
    }
}
