package com.example.weather;
import com.google.gson.annotations.SerializedName;

import java.util.List;
public class ResponseMyWeather {
    @SerializedName("main")
    private Main main;
    @SerializedName("Myweather")
    private List <MyWeather> weather;

    public Main getMain()  {
        return main;
    }

    public List<MyWeather> getWeather() {
        return weather;
    }


    public class Main {
        @SerializedName("temperature")
        private double temperature;
        @SerializedName("humidity")
        private int humidity;

        public double getTemperature() {
            return temperature;
        }

        public Object getHumidity() {
            return getHumidity();
        }
    }

    }


